#https://pysimplegui.trinket.io/demo-programs#/tables/the-table-element

import PySimpleGUI as sg
import csv
import os.path
import sounddevice as sd
import soundfile as sf
from scipy.io.wavfile import write
from pydub import AudioSegment, scipy_effects, effects
import simpleaudio as sa

fs = 44100  # Sample rate
seconds = 5  # Duration of recording

sg.change_look_and_feel('Light Green 1')

all_students = []
all_dips = []

dip_students = []

def hasAudio(sid):
    if os.path.isfile('audio/'+sid+'.wav'):
        return True
    else:
        return False

def selectDip(dip):
    global dip_students
    dip_students = []
    for i in all_students:
        if i[2] == dip:
            dip_students.append([i[1],i[0],hasAudio(i[0])])

def loadData(filename):
    global all_students, all_dips
    
    with open(filename) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for row in csv_reader:
            sid = row[0]
            name = row[1]
            dip = row[2]
            sch = row[4]
            session = row[5]
            
            all_students.append(row)
            
            if dip not in all_dips:
                all_dips.append(dip)
            
            line_count += 1
        print(f'Processed {line_count} lines.')
        #print(all_dips)
        
def detect_leading_silence(sound, silence_threshold=-50.0, chunk_size=10):
    '''
    sound is a pydub.AudioSegment
    silence_threshold in dB
    chunk_size in ms
    iterate over chunks until you find the first one with sound
    '''
    trim_ms = 0  # ms
    while sound[trim_ms:trim_ms+chunk_size].dBFS < silence_threshold:
        trim_ms += chunk_size

    return trim_ms

    
# ------ Make the Table Data ------
loadData('student_data.csv')
headings = ['Name','Student ID','Audio File']

#init using first dip as default
selectDip(all_dips[0])
#window['Change Dip'].update(default_value=all_dips[0])

# ------ Window Layout ------
layout = [[sg.Combo(all_dips,enable_events=True,key='Change Dip',default_value=all_dips[0])],
          [sg.Table(values=dip_students, headings=headings, max_col_width=50, background_color='lightblue',
                    auto_size_columns=True,
                    display_row_numbers=True,
                    justification='right',
                    num_rows=20,
                    key='-TABLE-')],
          [sg.Button('Record'), sg.Button('Playback')],
          [sg.Text('Record = Start recording selected name')],
          [sg.Text('Playback = Playback selected name')]]

# ------ Create Window ------
window = sg.Window('Name Recorder Automation', layout)



# ------ Event Loop ------
while True:
    event, values = window.read()
    #print(event, values)
    if event is None:
        break
    if event == 'Change Dip':
        selectDip(values['Change Dip'])
        window['-TABLE-'].update(values=dip_students)
    elif event == 'Record':
        selected_row = values['-TABLE-'][0]
        sid = dip_students[selected_row][1]
        
        #To record audio
        myrecording = sd.rec(int(seconds * fs), samplerate=fs, channels=1)
        sd.wait()  # Wait until recording is finished
        write('audio/'+sid+'.wav', fs, myrecording)  # Save as WAV file 
        
        #band-pass filter
        audio = AudioSegment.from_wav('audio/'+sid+'.wav')
        filtered = scipy_effects.band_pass_filter(audio,50,8000,order=5)        
       
        #volume normalization
        normalizedsound = effects.normalize(filtered) 
       
        #silence detection and truncation  
        start_trim = detect_leading_silence(normalizedsound)
        end_trim = detect_leading_silence(filtered.reverse())
        duration = len(filtered)
        trimmed_sound = filtered[start_trim:duration-end_trim]
        
        #padding 0.5s silence front and back
        half_sec_segment = AudioSegment.silent(duration=500)  #duration in milliseconds
        padded_sound = half_sec_segment + trimmed_sound + half_sec_segment
        
        #saving to <sid>.wav file
        padded_sound.export('audio/'+sid+'.wav', format="wav") 
                
        dip_students[selected_row][2] = True
        window['-TABLE-'].update(values=dip_students, select_rows=[selected_row])
        
    elif event == 'Playback':
        selected_row = values['-TABLE-'][0]
        sid = dip_students[selected_row][1]
        
        #To playback audio
        data, fs = sf.read('audio/'+sid+'.wav', dtype='float32')
        sd.play(data, fs)
        status = sd.wait()

window.close()

